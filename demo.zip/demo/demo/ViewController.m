//
//  ViewController.m
//  demo
//
//  Created by ashutosh on 15/11/17.
//  Copyright © 2017 ashutosh. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self apicall];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)apicall
{
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    manager.securityPolicy.allowInvalidCertificates = YES;//This is for https
    [manager.securityPolicy setValidatesDomainName:NO];
    [manager.requestSerializer setValue:@"admin@restuser" forHTTPHeaderField:@"x_rest_username"];
    [manager.requestSerializer setValue:@"admin@Access" forHTTPHeaderField:@"x_rest_password"];
    [manager.requestSerializer setValue:@"v1" forHTTPHeaderField:@"x_rest_version"];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    
    NSString *urlString = [NSString stringWithFormat:@"%@%@",@"http://tarexapp.coherentlab.com/",@"user/getusermatch"];
    NSDictionary *dict=@{@"user_id":@"52",@"category_id":@"2",@"type":@""};
    [manager POST:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData)
     {
         
     }success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSDictionary *responseJson = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
         NSLog(@"Response String %@",responseJson);
         NSString * status=[NSString stringWithFormat:@"%@",[responseJson valueForKey:@"status"]];
         if ([status isEqualToString: @"200"] ) {
             
             
                     }
         else if([status isEqualToString: @"400"])
         {
                     }
         else
         {
                      }
     }
          failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"error ---  %@",error.description);
         
     }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
